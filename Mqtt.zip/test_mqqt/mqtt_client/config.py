from data import database 

data = database.fetch_data()

Broker = data.get('Broker')
print("Broker")
Port = 1883
keepalive = 60
