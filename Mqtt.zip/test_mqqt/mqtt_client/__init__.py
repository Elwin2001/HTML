import paho.mqtt.client as mqtt

def on_connect(client, userdata, flags, reason_code, properties=None):
    if reason_code == 0:
        print("Connected successfully")
    else:
        print("Connection unsuccessful")

def mqtts():
    print("ESTD CLIENT")
    con = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
    print("ESTD CLIENT SUC")

    print("Entered into callback function")
    con.on_connect = on_connect
    return con
    
def publish(client,topic,payload,qos ):
    print("Publish Value to Broker")
    client.publish(topic,payload)
    print(topic,payload)
    print("sucessfully Published")
