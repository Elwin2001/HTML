import sqlite3 

print("Establishing connection for Database")
connection = sqlite3.connect("database/Device_data.db")
print("Connection for database Established Sucessfully")

data = {}

def fetch_data():
    cursor = connection.execute("SELECT DATA_NAME, DATA_VALUE FROM Device_info WHERE DATA_NAME IN ('Device id', 'Broker')")
    value = cursor.fetchall()
    for row in value:
      data_name, data_value = row
      data[data_name] = data_value

    return data  

