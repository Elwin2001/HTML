from mqtt_client import mqtts,publish
from mqtt_client import config
import random as ran
import time

def main():
    
    client = mqtts()
    client.loop_start()
    

    try:
        client.connect(config.Broker,config.Port,config.keepalive)
        time.sleep(2)
        for i in range(10):
           random_value = ran.randint(1,100)
           publish(client,topic=(f"{config.data.get('Device id')}/temp"),payload=random_value,qos=3)
           print(f"{config.data.get('Device id')}/temp")
           time.sleep(10)
        

    except Exception as a:
        print(f"Error {str(a)}")
    finally: 

        client.loop_stop()
        print("Loop stopped")

if __name__ == '__main__':
    main()
